"""
Modelos Pydantic para el simulador de planificación de CPU.

Process         → datos de entrada de cada proceso
GanttSlot       → una ranura en el diagrama de Gantt
SimulationResult→ resultado completo de una simulación
"""

from typing import List, Optional, Dict
from pydantic import BaseModel, Field, field_validator


class Process(BaseModel):
    """Representa un proceso a planificar."""
    pid: str = Field(..., description="Identificador único del proceso (ej: P1)")
    arrival_time: int = Field(..., ge=0, description="Tiempo de llegada")
    burst_time: int = Field(..., ge=1, description="Tiempo de ráfaga (CPU burst)")
    priority: int = Field(default=0, description="Prioridad (menor número = mayor prioridad lógica)")

    @field_validator("pid")
    @classmethod
    def pid_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("El PID no puede estar vacío")
        return v.strip()


class GanttSlot(BaseModel):
    """
    Representa un bloque de tiempo en el diagrama de Gantt.

    Estado posibles:
      - 'running'   : proceso ejecutándose en CPU
      - 'idle'      : CPU inactiva (sin proceso)
      - 'waiting'   : proceso esperando en cola de listos
      - 'arrival'   : instante exacto de llegada de un proceso
    """
    pid: str = Field(..., description="PID del proceso o 'IDLE'")
    start: int = Field(..., ge=0, description="Tiempo de inicio del slot")
    end: int = Field(..., description="Tiempo de fin del slot")
    state: str = Field(
        default="running",
        description="Estado: running | idle | waiting | arrival"
    )
    interrupted: bool = Field(
        default=False,
        description="True si el proceso fue interrumpido (expropiado) al finalizar este slot"
    )

    @field_validator("state")
    @classmethod
    def valid_state(cls, v: str) -> str:
        allowed = {"running", "idle", "waiting", "arrival"}
        if v not in allowed:
            raise ValueError(f"Estado inválido '{v}'. Permitidos: {allowed}")
        return v


class ProcessMetrics(BaseModel):
    """Métricas individuales calculadas para un proceso."""
    pid: str
    arrival_time: int
    burst_time: int
    priority: int

    # Tiempos absolutos
    start_time: int = Field(..., description="Primera vez que el proceso entró a la CPU")
    finish_time: int = Field(..., description="Tiempo en que el proceso terminó completamente")

    # Métricas derivadas
    # Tiempo de retorno (Turnaround Time) = finish_time - arrival_time
    turnaround_time: int = Field(..., description="finish_time - arrival_time")
    # Tiempo de espera (Waiting Time) = turnaround_time - burst_time
    waiting_time: int = Field(..., description="turnaround_time - burst_time")
    # Tiempo de respuesta (Response Time) = start_time - arrival_time
    response_time: int = Field(..., description="start_time - arrival_time")


class SimulationAverages(BaseModel):
    """Promedios globales de la simulación."""
    avg_turnaround: float
    avg_waiting: float
    avg_response: float


class SimulationResult(BaseModel):
    """Resultado completo de una simulación."""
    algorithm: str
    gantt: List[GanttSlot] = Field(..., description="Secuencia de slots del Gantt")
    metrics: List[ProcessMetrics] = Field(..., description="Métricas por proceso")
    averages: SimulationAverages
    total_time: int = Field(..., description="Tiempo total de simulación")

    # timeline: mapa tiempo → PID que se ejecuta (o 'IDLE')
    timeline: Dict[int, str] = Field(
        default_factory=dict,
        description="Mapa {tick: pid_o_IDLE} para construir la matriz del Gantt"
    )


class SimulationRequest(BaseModel):
    """Cuerpo del POST /simulate."""
    algorithm: str = Field(..., description="Nombre del algoritmo: fcfs | sjf | srtf | priority | rr")
    processes: List[Process] = Field(..., min_length=1, description="Lista de procesos")
    quantum: Optional[int] = Field(default=2, ge=1, description="Quantum para Round Robin")

    @field_validator("algorithm")
    @classmethod
    def valid_algorithm(cls, v: str) -> str:
        allowed = {"fcfs", "sjf", "srtf", "priority", "rr"}
        v = v.lower().strip()
        if v not in allowed:
            raise ValueError(f"Algoritmo '{v}' no soportado. Opciones: {allowed}")
        return v
