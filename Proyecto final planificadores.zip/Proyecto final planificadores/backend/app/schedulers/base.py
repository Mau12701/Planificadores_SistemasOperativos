

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Optional

from app.models.schemas import (
    Process,
    GanttSlot,
    ProcessMetrics,
    SimulationAverages,
    SimulationResult,
)


@dataclass
class _ProcState:
    """Estado mutable de un proceso durante la simulación."""
    pid: str
    arrival_time: int
    burst_time: int
    priority: int

    remaining: int = field(init=False)          # Tiempo de ráfaga restante
    start_time: Optional[int] = field(default=None)   # Primera entrada a CPU
    finish_time: Optional[int] = field(default=None)  # Tiempo de finalización

    def __post_init__(self):
        self.remaining = self.burst_time

    @property
    def is_done(self) -> bool:
        return self.remaining <= 0


class BaseScheduler(ABC):
    """
    Clase base abstracta para planificadores de CPU.

    Subclases deben implementar `_run()` que produce el timeline:
        Dict[int, str]  →  { tick: pid_o_"IDLE" }
    """

    def __init__(self, processes: List[Process], quantum: int = 2):
        # Crear estados internos ordenados por llegada, luego por prioridad
        self._states: Dict[str, _ProcState] = {
            p.pid: _ProcState(
                pid=p.pid,
                arrival_time=p.arrival_time,
                burst_time=p.burst_time,
                priority=p.priority,
            )
            for p in sorted(processes, key=lambda p: (p.arrival_time, p.priority, p.pid))
        }
        self._quantum = quantum
        self._processes_input = processes

    # ------------------------------------------------------------------ #
    #  Método principal                                                     #
    # ------------------------------------------------------------------ #

    def simulate(self) -> SimulationResult:
        """Ejecuta la simulación completa y devuelve el resultado."""
        timeline: Dict[int, str] = self._run()

        gantt = self._build_gantt(timeline)
        metrics = self._calc_metrics()
        averages = self._calc_averages(metrics)
        total_time = max(timeline.keys()) + 1 if timeline else 0

        return SimulationResult(
            algorithm=self.name,
            gantt=gantt,
            metrics=metrics,
            averages=averages,
            total_time=total_time,
            timeline=timeline,
        )

    # ------------------------------------------------------------------ #
    #  Método abstracto que cada algoritmo debe implementar               #
    # ------------------------------------------------------------------ #

    @abstractmethod
    def _run(self) -> Dict[int, str]:
        """
        Ejecutar el algoritmo y devolver:
            { tick: pid_o_"IDLE" }
        tick comienza en 0.
        """
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Nombre identificador del algoritmo."""
        ...

    # ------------------------------------------------------------------ #
    #  Helpers compartidos                                                  #
    # ------------------------------------------------------------------ #

    def _get_ready(self, tick: int) -> List[_ProcState]:
        """Devuelve procesos que ya llegaron y aún no han terminado."""
        return [
            s for s in self._states.values()
            if s.arrival_time <= tick and not s.is_done
        ]

    def _mark_start(self, state: _ProcState, tick: int):
        """Registra la primera vez que un proceso entra a la CPU."""
        if state.start_time is None:
            state.start_time = tick

    def _mark_finish(self, state: _ProcState, tick: int):
        """Registra cuando el proceso termina."""
        state.finish_time = tick

    # ------------------------------------------------------------------ #
    #  Construcción del Gantt                                               #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_gantt(timeline: Dict[int, str]) -> List[GanttSlot]:
        """
        Consolida el timeline tick-a-tick en GanttSlots comprimidos.

        Ejemplo:
            {0:'P1', 1:'P1', 2:'P2'} →
            [GanttSlot(P1, 0, 2), GanttSlot(P2, 2, 3)]
        """
        if not timeline:
            return []

        slots: List[GanttSlot] = []
        ticks = sorted(timeline.keys())

        current_pid = timeline[ticks[0]]
        start = ticks[0]

        for i in range(1, len(ticks)):
            tick = ticks[i]
            pid = timeline[tick]
            if pid != current_pid:
                # Detectar si hubo interrupción (proceso que no era IDLE
                # es reemplazado por otro proceso antes de terminar)
                interrupted = (
                    current_pid != "IDLE"
                    and pid != "IDLE"
                    # Si el proceso reemplazado aún no ha terminado
                    # se infiere interrupción (se verifica en subclase)
                )
                slots.append(GanttSlot(
                    pid=current_pid,
                    start=start,
                    end=tick,
                    state="idle" if current_pid == "IDLE" else "running",
                    interrupted=interrupted,
                ))
                current_pid = pid
                start = tick

        # Último bloque
        last_tick = ticks[-1]
        slots.append(GanttSlot(
            pid=current_pid,
            start=start,
            end=last_tick + 1,
            state="idle" if current_pid == "IDLE" else "running",
            interrupted=False,
        ))

        return slots

    # ------------------------------------------------------------------ #
    #  Cálculo de métricas                                                  #
    # ------------------------------------------------------------------ #

    def _calc_metrics(self) -> List[ProcessMetrics]:
        metrics = []
        for pid, s in self._states.items():
            if s.finish_time is None or s.start_time is None:
                continue  # Proceso que nunca llegó a ejecutarse
            tt = s.finish_time - s.arrival_time
            wt = tt - s.burst_time
            rt = s.start_time - s.arrival_time
            metrics.append(ProcessMetrics(
                pid=s.pid,
                arrival_time=s.arrival_time,
                burst_time=s.burst_time,
                priority=s.priority,
                start_time=s.start_time,
                finish_time=s.finish_time,
                turnaround_time=tt,
                waiting_time=wt,
                response_time=rt,
            ))
        return sorted(metrics, key=lambda m: m.pid)

    def _calc_averages(self, metrics: List[ProcessMetrics]) -> SimulationAverages:
        n = len(metrics)
        if n == 0:
            return SimulationAverages(avg_turnaround=0, avg_waiting=0, avg_response=0)
        return SimulationAverages(
            avg_turnaround=round(sum(m.turnaround_time for m in metrics) / n, 2),
            avg_waiting=round(sum(m.waiting_time for m in metrics) / n, 2),
            avg_response=round(sum(m.response_time for m in metrics) / n, 2),
        )
