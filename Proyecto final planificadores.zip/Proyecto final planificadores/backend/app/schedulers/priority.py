
from typing import Dict, List
from app.schedulers.base import BaseScheduler, _ProcState


class PriorityScheduler(BaseScheduler):

    @property
    def name(self) -> str:
        return "priority"

    def _run(self) -> Dict[int, str]:
        timeline: Dict[int, str] = {}
        tick = 0
        completed = set()

        while len(completed) < len(self._states):
            available: List[_ProcState] = [
                s for s in self._states.values()
                if s.arrival_time <= tick and s.pid not in completed
            ]

            if not available:
                timeline[tick] = "IDLE"
                tick += 1
                continue

            # Selección expropiativa tick a tick:
            # 1. Prioridad (menor número = mayor prioridad)
            # 2. burst_time original (SJF como desempate de prioridad igual)
            # 3. PID como último desempate
            chosen: _ProcState = min(
                available,
                key=lambda s: (s.priority, s.burst_time, s.pid)
            )

            self._mark_start(chosen, tick)
            timeline[tick] = chosen.pid
            chosen.remaining -= 1
            tick += 1

            if chosen.remaining == 0:
                self._mark_finish(chosen, tick)
                completed.add(chosen.pid)

        return timeline
