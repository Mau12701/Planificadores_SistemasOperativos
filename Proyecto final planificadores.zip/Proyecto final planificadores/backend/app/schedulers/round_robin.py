
from collections import deque
from typing import Dict, Deque
from app.schedulers.base import BaseScheduler, _ProcState


class RoundRobinScheduler(BaseScheduler):

    @property
    def name(self) -> str:
        return "rr"

    def _run(self) -> Dict[int, str]:
        timeline: Dict[int, str] = {}
        tick = 0
        completed = set()
        in_queue: set = set()   # PIDs que ya están en la cola (para no duplicar)

        # Cola de listos (FIFO con entrada por prioridad en empates)
        ready: Deque[_ProcState] = deque()

        def enqueue_arrivals(since: int, until: int, exclude: str = ""):
    
            arrived = sorted(
                [
                    s for s in self._states.values()
                    if since <= s.arrival_time < until
                    and s.pid not in completed
                    and s.pid not in in_queue
                    and s.pid != exclude
                ],
                key=lambda s: (s.arrival_time, s.priority, s.pid)
            )
            for s in arrived:
                ready.append(s)
                in_queue.add(s.pid)

        # Cargar procesos que llegan en t=0
        enqueue_arrivals(0, 1)

        while len(completed) < len(self._states):
            # Si la cola está vacía → CPU idle hasta el próximo arribo
            if not ready:
                # Avanzar hasta el próximo proceso que llega
                next_arrival = min(
                    s.arrival_time
                    for s in self._states.values()
                    if s.pid not in completed and s.pid not in in_queue
                )
                while tick < next_arrival:
                    timeline[tick] = "IDLE"
                    tick += 1
                enqueue_arrivals(tick, tick + 1)
                continue

            # Tomar el siguiente proceso de la cola
            current: _ProcState = ready.popleft()
            in_queue.discard(current.pid)

            self._mark_start(current, tick)

            # Ejecutar min(quantum, remaining) ticks
            exec_time = min(self._quantum, current.remaining)
            quantum_start = tick

            for _ in range(exec_time):
                timeline[tick] = current.pid
                current.remaining -= 1
                tick += 1

            # Procesos que llegaron DURANTE este quantum (antes de reencolar el actual)
            enqueue_arrivals(quantum_start + 1, tick, exclude=current.pid)

            if current.remaining == 0:
                self._mark_finish(current, tick)
                completed.add(current.pid)
            else:
                # Proceso expropiado → va al FINAL de la cola
                ready.append(current)
                in_queue.add(current.pid)

            # También capturar proceso que llega exactamente en `tick`
            enqueue_arrivals(tick, tick + 1, exclude=current.pid if current.pid in in_queue else "")

        return timeline
