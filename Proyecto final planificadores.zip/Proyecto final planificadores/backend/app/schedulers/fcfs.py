

from typing import Dict, List
from app.schedulers.base import BaseScheduler, _ProcState
from app.models.schemas import Process


class FCFSScheduler(BaseScheduler):

    @property
    def name(self) -> str:
        return "fcfs"

    def _run(self) -> Dict[int, str]:
        timeline: Dict[int, str] = {}
        tick = 0

        # Ordenar procesos por llegada, desempate por prioridad, luego PID
        order: List[_ProcState] = sorted(
            self._states.values(),
            key=lambda s: (s.arrival_time, s.priority, s.pid)
        )

        for state in order:
            # Si el proceso aún no llegó, la CPU queda IDLE hasta que llegue
            while tick < state.arrival_time:
                timeline[tick] = "IDLE"
                tick += 1

            # Ejecutar el proceso completo (no expropiativo)
            self._mark_start(state, tick)
            for _ in range(state.burst_time):
                timeline[tick] = state.pid
                state.remaining -= 1
                tick += 1
            self._mark_finish(state, tick)

        return timeline
