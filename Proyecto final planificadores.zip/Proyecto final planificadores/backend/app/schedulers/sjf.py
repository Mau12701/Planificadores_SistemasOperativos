

from typing import Dict, List, Optional
from app.schedulers.base import BaseScheduler, _ProcState
from app.models.schemas import Process


class SJFScheduler(BaseScheduler):

    @property
    def name(self) -> str:
        return "sjf"

    def _run(self) -> Dict[int, str]:
        timeline: Dict[int, str] = {}
        tick = 0
        completed = set()

        while len(completed) < len(self._states):
            # Obtener procesos disponibles (llegaron, no terminaron)
            available: List[_ProcState] = [
                s for s in self._states.values()
                if s.arrival_time <= tick and s.pid not in completed
            ]

            if not available:
                # CPU idle: avanzar al próximo evento de llegada
                timeline[tick] = "IDLE"
                tick += 1
                continue

            # SELECCIÓN: menor burst, desempate prioridad, desempate PID
            # Esta selección ocurre UNA VEZ y no cambia hasta que termina
            chosen: _ProcState = min(
                available,
                key=lambda s: (s.burst_time, s.priority, s.pid)
            )

            # Ejecutar COMPLETAMENTE (no expropiativo)
            self._mark_start(chosen, tick)
            for _ in range(chosen.remaining):
                timeline[tick] = chosen.pid
                tick += 1
            chosen.remaining = 0
            self._mark_finish(chosen, tick)
            completed.add(chosen.pid)

        return timeline
