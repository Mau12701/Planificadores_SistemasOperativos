

from typing import Dict, List, Optional
from app.schedulers.base import BaseScheduler, _ProcState
from app.models.schemas import Process


class SRTFScheduler(BaseScheduler):

    @property
    def name(self) -> str:
        return "srtf"

    def _run(self) -> Dict[int, str]:
        timeline: Dict[int, str] = {}
        tick = 0
        completed = set()

        while len(completed) < len(self._states):
            # Procesos disponibles en este tick
            available: List[_ProcState] = [
                s for s in self._states.values()
                if s.arrival_time <= tick and s.pid not in completed
            ]

            if not available:
                timeline[tick] = "IDLE"
                tick += 1
                continue

            # Selección expropiativa: menor remaining en CADA tick
            chosen: _ProcState = min(
                available,
                key=lambda s: (s.remaining, s.priority, s.pid)
            )

            self._mark_start(chosen, tick)
            timeline[tick] = chosen.pid
            chosen.remaining -= 1
            tick += 1

            if chosen.remaining == 0:
                self._mark_finish(chosen, tick)
                completed.add(chosen.pid)

        return timeline
