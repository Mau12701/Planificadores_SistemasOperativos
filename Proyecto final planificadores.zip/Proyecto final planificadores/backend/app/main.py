

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.endpoints import router

app = FastAPI(
    title="CPU Scheduler Simulator",
    description="Simulador académico de algoritmos de planificación de CPU",
    version="1.0.0",
)

# CORS: permitir acceso desde cualquier origen (desarrollo local)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registrar rutas
app.include_router(router, prefix="/api")


@app.get("/", summary="Health check")
def root():
    return {"status": "ok", "service": "cpu-scheduler-simulator"}


@app.get("/health")
def health():
    return {"status": "healthy"}
