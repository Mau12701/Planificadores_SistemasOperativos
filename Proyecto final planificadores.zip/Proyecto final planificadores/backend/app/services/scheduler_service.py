"""
scheduler_service.py — Registro central de algoritmos disponibles.

Actúa como una fábrica: recibe el nombre del algoritmo y devuelve
la instancia correcta del planificador.
"""

from typing import Dict, Any, List
from app.models.schemas import Process, SimulationResult
from app.schedulers.fcfs import FCFSScheduler
from app.schedulers.sjf import SJFScheduler
from app.schedulers.srtf import SRTFScheduler
from app.schedulers.priority import PriorityScheduler
from app.schedulers.round_robin import RoundRobinScheduler


# Registro de algoritmos disponibles
ALGORITHM_REGISTRY: Dict[str, Any] = {
    "fcfs": FCFSScheduler,
    "sjf": SJFScheduler,
    "srtf": SRTFScheduler,
    "priority": PriorityScheduler,
    "rr": RoundRobinScheduler,
}

ALGORITHM_DESCRIPTIONS = {
    "fcfs": {
        "id": "fcfs",
        "name": "FCFS / FIFO",
        "description": "First Come First Served — No expropiativo. Los procesos ejecutan en orden de llegada.",
        "preemptive": False,
        "uses_quantum": False,
    },
    "sjf": {
        "id": "sjf",
        "name": "SJF",
        "description": "Shortest Job First — No expropiativo. Elige el proceso con menor ráfaga al terminar el actual.",
        "preemptive": False,
        "uses_quantum": False,
    },
    "srtf": {
        "id": "srtf",
        "name": "SRTF",
        "description": "Shortest Remaining Time First — Expropiativo. En cada tick elige el menor tiempo restante.",
        "preemptive": True,
        "uses_quantum": False,
    },
    "priority": {
        "id": "priority",
        "name": "Prioridades",
        "description": "Priority Scheduling — Expropiativo. Menor número = mayor prioridad. SJF como desempate.",
        "preemptive": True,
        "uses_quantum": False,
    },
    "rr": {
        "id": "rr",
        "name": "Round Robin",
        "description": "Round Robin — Expropiativo por quantum. Fairness garantizada mediante cola FIFO.",
        "preemptive": True,
        "uses_quantum": True,
    },
}


def get_available_algorithms() -> List[Dict]:
    return list(ALGORITHM_DESCRIPTIONS.values())


def run_simulation(
    algorithm: str,
    processes: List[Process],
    quantum: int = 2,
) -> SimulationResult:
    """
    Instancia el planificador correcto y ejecuta la simulación.

    Raises:
        ValueError: si el algoritmo no existe en el registro.
    """
    key = algorithm.lower().strip()
    if key not in ALGORITHM_REGISTRY:
        raise ValueError(f"Algoritmo '{algorithm}' no registrado. Disponibles: {list(ALGORITHM_REGISTRY.keys())}")

    scheduler_cls = ALGORITHM_REGISTRY[key]
    scheduler = scheduler_cls(processes=processes, quantum=quantum)
    return scheduler.simulate()
