"""
endpoints.py — Rutas de la API REST

POST /simulate  → ejecutar simulación
GET  /algorithms → listar algoritmos disponibles
"""

from fastapi import APIRouter, HTTPException
from app.models.schemas import SimulationRequest, SimulationResult
from app.services.scheduler_service import run_simulation, get_available_algorithms

router = APIRouter()


@router.get("/algorithms", summary="Listar algoritmos disponibles")
def list_algorithms():
    """Devuelve los algoritmos de planificación soportados con sus metadatos."""
    return {"algorithms": get_available_algorithms()}


@router.post("/simulate", response_model=SimulationResult, summary="Ejecutar simulación")
def simulate(request: SimulationRequest):
    """
    Ejecuta el algoritmo indicado sobre la lista de procesos.

    - **algorithm**: fcfs | sjf | srtf | priority | rr
    - **processes**: lista de procesos con pid, arrival_time, burst_time, priority
    - **quantum**: tiempo de quantum para Round Robin (ignorado en otros algoritmos)
    """
    try:
        result = run_simulation(
            algorithm=request.algorithm,
            processes=request.processes,
            quantum=request.quantum or 2,
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")
